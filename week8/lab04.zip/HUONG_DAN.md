# Lab 4 - SOA Buoi 8

Bao cao: week8/lab4/analysis.md.
Huong dan chay: week8/lab4/README.md.
Tu thu muc giai nen: tao week8/.venv, cai week8/requirements-lock.txt, chay week8/lab4/run_load_test.py --bonus.
Khong can cac thu muc bai tap tuan khac de chay Lab 4.
